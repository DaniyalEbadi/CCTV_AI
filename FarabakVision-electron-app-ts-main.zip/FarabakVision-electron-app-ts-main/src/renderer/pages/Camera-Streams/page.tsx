const CameraStreamsPage = () => {
  return <div>CameraStreamsPage</div>;
};
export default CameraStreamsPage;
